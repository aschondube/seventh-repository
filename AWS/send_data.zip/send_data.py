import psycopg2
import json
import os

def send_data(crypto_data):
  """
  Sends retrieved crypto data to a PostgreSQL database using environment variables.

  Args:
      crypto_data (dict): Dictionary containing crypto data in JSON format.
  """

  # Retrieve database connection URL from environment variable
  db_url = os.getenv('db_url')

  # Connect to the PostgreSQL database
  try:
    conn = psycopg2.connect(db_url)
    cur = conn.cursor()
  except Exception as error:
    print(f"Error connecting to database: {error}")
    return

  # Prepare SQL statement for insertion (unchanged)
  insert_query = """
    INSERT INTO btc_prices(date, open, high, low, close, volume)
    VALUES (%s, %s, %s, %s, %s, %s)
    ON CONFLICT (date) DO NOTHING
  """

  # Iterate through each date-data pair in the JSON (unchanged)
  for date, daily_data in crypto_data.items():
    try:
      # Extract data from daily_data dictionary (unchanged)
      open_price = daily_data["1. open"]
      high_price = daily_data["2. high"]
      low_price = daily_data["3. low"]
      close_price = daily_data["4. close"]
      volume = daily_data["5. volume"]

      # Execute the insert query with specific data for each day (unchanged)
      cur.execute(insert_query, (date, open_price, high_price, low_price, close_price, volume))
    except Exception as error:
      print(f"Error inserting data for {date}: {error}")
      continue  # Continue to next date on error

  # Commit the changes to the database (unchanged)
  conn.commit()
  cur.close()
  conn.close()

  print("Successfully sent data to PostgreSQL database.")

# Example usage (assuming data retrieved from get_crypto_data)
# send_data(crypto_data)
