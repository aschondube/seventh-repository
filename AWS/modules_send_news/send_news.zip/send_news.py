import psycopg2
import json
import os

def send_data(event, context):
  """
  Sends retrieved news data to a PostgreSQL database using environment variables.

  Args:
      event (dict): Dictionary containing the event data (including crypto data in JSON format).
      context (object): Lambda context object (not used in this function).
  """

    # Check if 'news_data' key is in the event
  #if 'news_data' not in event:
     # print("Error: 'news_data' key not found in event")
     # return


  # Extract crypto data from event
  news_data = event['responsePayload']

  # Retrieve database connection URL from environment variable
  db_url = os.getenv('db_url')

  # Connect to the PostgreSQL database
  try:
    conn = psycopg2.connect(db_url)
    cur = conn.cursor()
  except Exception as error:
    print(f"Error connecting to database: {error}")
    return {
            'statusCode': 500,
            'body': json.dumps('Database connection error')
        }

  # Prepare SQL statement for insertion (unchanged)
  insert_query = """
    INSERT INTO btc_news (date, title)
    VALUES (%s, %s)
    ON CONFLICT (title) DO NOTHING
  """

  # Iterate through each date-data pair in the JSON (unchanged)
  for date, daily_data in news_data.items():
    try:
      # Extract data from daily_data dictionary (unchanged)
      title_news = daily_data["title"]

      # Execute the insert query with specific data for each day (unchanged)
      cur.execute(insert_query, (date, title_news))
    except Exception as error:
      print(f"Error inserting data for {date}: {error}")
      continue  # Continue to next date on error
    # Commit the changes to the database
    try:
        conn.commit()
    except Exception as error:
        print(f"Error committing changes to the database: {error}")
        return {
            'statusCode': 500,
            'body': json.dumps('Error committing changes to the database')
        }
    finally:
        cur.close()
        conn.close()

    print("Successfully sent data to PostgreSQL database.")
    return {
        'statusCode': 200,
        'body': json.dumps('Successfully sent data to PostgreSQL database')
    }

# Mock event and context for local testing
mock_event = {
    'responsePayload': json.dumps({
        '2024-05-30': {'title': 'European bitcoin ETPs suffer mounting outflows'},
        '2024-05-24': {'title': 'British-Chinese bitcoin money launderer jailed for over 6 years'}
    })
}
mock_context = None

response = send_data(mock_event, mock_context)
print(response)


